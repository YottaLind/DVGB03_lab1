#include "analyze.h"
#include "io.h"

#ifndef UI_H
#define UI_H

void terminal();

#endif