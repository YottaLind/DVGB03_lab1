#include "ui.h"

int main()
{
	terminal();
}
